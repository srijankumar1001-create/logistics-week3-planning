"""
generate_dataset.py — Week 3 logistics internship report
Generates a synthetic but realistic 6-month last-mile delivery dataset for a
regional distribution hub (urban + semi-urban zones).

Fixed seed => reproducible. Outputs CSVs to ../data/.
Run:  python generate_dataset.py
"""
import numpy as np
import pandas as pd

SEED = 202603
rng = np.random.default_rng(SEED)

DATA = "data"  # run from ~/workspace/logistics_week3_report/

# ---------------------------------------------------------------- time axis
START, END = "2026-04-01", "2026-09-30"
dates = pd.date_range(START, END, freq="D")
n_days = len(dates)

# ---------------------------------------------------------------- fuel price
# Rs./litre: gentle upward drift with weekly noise, mean ~= 96
fuel = 94.0 + 0.02 * np.arange(n_days) + rng.normal(0, 0.9, n_days)
fuel = np.clip(fuel, 90, 103)
fuel_s = pd.Series(fuel, index=dates)

# --------------------------------------------------------------- daily volume
# base 175/day, growth trend, weekend dip, promotional spikes
dow_mult = {0: 1.05, 1: 1.00, 2: 1.00, 3: 1.02, 4: 1.10, 5: 0.85, 6: 0.72}
spikes = [("2026-06-15", "2026-06-21", 1.45, "Summer Sale"),
          ("2026-07-20", "2026-07-22", 1.30, "Monsoon Clearance"),
          ("2026-08-13", "2026-08-16", 1.60, "Independence Day Sale")]
daily = []
for i, d in enumerate(dates):
    v = 175 * (1 + 0.0015 * i) * dow_mult[d.dayofweek]
    for s, e, m, _ in spikes:
        if s <= d.strftime("%Y-%m-%d") <= e:
            v *= m
    daily.append(v)
daily = np.array(daily) * rng.normal(1, 0.06, n_days)
daily = np.clip(daily, 60, None).astype(int)

# ------------------------------------------------------------------- zones
zones = ["Z1", "Z2", "Z3", "Z4", "Z5", "Z6", "Z7", "Z8"]
ztype = {"Z1": "urban", "Z2": "urban", "Z3": "urban", "Z4": "urban",
         "Z5": "semi-urban", "Z6": "semi-urban", "Z7": "urban-congested", "Z8": "semi-urban"}
share = {"Z1": .18, "Z2": .16, "Z3": .14, "Z4": .12,
         "Z5": .10, "Z6": .08, "Z7": .12, "Z8": .10}
base_hours = {"Z1": 26, "Z2": 27, "Z3": 28, "Z4": 30,
              "Z5": 36, "Z6": 33, "Z7": 34, "Z8": 38}
fail_p = {"Z1": .07, "Z2": .08, "Z3": .08, "Z4": .09,
          "Z5": .14, "Z6": .10, "Z7": .16, "Z8": .12}
plan_km_mean = {"Z1": 6, "Z2": 6, "Z3": 6.5, "Z4": 7,
                "Z5": 14, "Z6": 13, "Z7": 6.5, "Z8": 15}
dev_mean = {"Z1": .10, "Z2": .11, "Z3": .12, "Z4": .12,
            "Z5": .20, "Z6": .15, "Z7": .14, "Z8": .18}

fail_reasons = ["Customer unavailable", "Wrong/incomplete address",
                "Gated community - no access code", "Vehicle breakdown",
                "Weather disruption"]
fail_w = [0.45, 0.25, 0.15, 0.08, 0.07]

vehicles = [f"V{i:02d}" for i in range(1, 13)]
SLA_H = 48

rows = []
did = 0
monsoon = dates >= "2026-06-01"
for i, d in enumerate(dates):
    n = daily[i]
    z_draw = rng.choice(zones, size=n, p=[share[z] for z in zones])
    for z in z_draw:
        did += 1
        # delivery time (hours): lognormal with long tail; monsoon penalty
        mu = np.log(base_hours[z]) + (0.13 if (monsoon[i] and ztype[z] == "semi-urban") else 0.0)
        if rng.random() < 0.06:            # extreme-tail cases
            hrs = rng.lognormal(4.2, 0.7)
        else:
            hrs = rng.lognormal(mu, 0.55)
        hrs = float(np.clip(hrs, 4, 220))
        # first-attempt failure
        failed = rng.random() < fail_p[z]
        reason = rng.choice(fail_reasons, p=fail_w) if failed else ""
        # distance
        planned = float(rng.gamma(9, plan_km_mean[z] / 9))
        actual = planned * (1 + rng.normal(dev_mean[z], 0.08))
        actual = max(actual, planned * 0.85)
        # cost: fixed handling + distance x fuel-linked per-km rate + noise
        # (per-km rate moves with fuel price so daily-average cost tracks fuel)
        per_km = 3.0 + 0.12 * fuel[i]
        cost = 30 + actual * per_km + rng.normal(0, 5)
        cost = max(cost, 40)
        rows.append({
            "delivery_id": f"D{did:06d}", "date": d.date().isoformat(),
            "zone": z, "zone_type": ztype[z], "vehicle_id": rng.choice(vehicles),
            "package_kg": round(float(rng.gamma(4, 0.9)), 2),
            "planned_km": round(planned, 2), "actual_km": round(actual, 2),
            "route_deviation_pct": round((actual - planned) / planned * 100, 1),
            "delivery_hours": round(hrs, 1),
            "on_time": hrs <= SLA_H,
            "first_attempt_failed": failed,
            "failure_reason": reason,
            "cost_per_delivery_rs": round(cost, 2),
            "fuel_price_rs_l": round(float(fuel[i]), 2),
        })

deliveries = pd.DataFrame(rows)

# ---------------------------------------------------------------- inventory
cats = ["FMCG", "Apparel", "Electronics", "Home Goods"]
months = pd.period_range("2026-04", "2026-09", freq="M")
inv_rows = []
base_turn = {"FMCG": 6.2, "Apparel": 2.4, "Electronics": 3.1, "Home Goods": 2.0}
for m in months:
    for c in cats:
        turn = base_turn[c] * rng.normal(1, 0.12)
        stockout = int(max(0, rng.normal(9 if c in ("Apparel", "Home Goods") else 4, 3)))
        inv_rows.append({"month": str(m), "category": c,
                        "inventory_turnover": round(max(turn, 0.5), 2),
                        "stockout_days": stockout})
inventory = pd.DataFrame(inv_rows)

# ------------------------------------------------------------------- save
import os
os.makedirs(DATA, exist_ok=True)
deliveries.to_csv(f"{DATA}/deliveries.csv", index=False)
pd.DataFrame({"date": dates.date.astype(str) if hasattr(dates.date, "astype")
              else [d.date().isoformat() for d in dates],
              "fuel_price_rs_l": np.round(fuel, 2),
              "shipments": daily}).to_csv(f"{DATA}/daily_volume.csv", index=False)
inventory.to_csv(f"{DATA}/inventory_monthly.csv", index=False)

# ------------------------------------------------------------- sanity print
print(f"deliveries: {len(deliveries):,} rows | {deliveries['date'].min()} to {deliveries['date'].max()}")
print(f"OTD rate: {deliveries['on_time'].mean()*100:.1f}% | "
      f"first-attempt failure: {deliveries['first_attempt_failed'].mean()*100:.1f}%")
print(f"avg cost/delivery: Rs.{deliveries['cost_per_delivery_rs'].mean():.1f} | "
      f"avg route deviation: {deliveries['route_deviation_pct'].mean():.1f}%")
print(f"delivery_hours p50/p90/p99: "
      f"{deliveries['delivery_hours'].quantile(.5):.1f} / "
      f"{deliveries['delivery_hours'].quantile(.9):.1f} / "
      f"{deliveries['delivery_hours'].quantile(.99):.1f}")
