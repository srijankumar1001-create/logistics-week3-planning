"""
make_charts.py — Week 3 logistics internship report
Loads data/, computes chart statistics (printed for use in the report prose),
and saves 8 PNG charts to charts/.
Run:  python make_charts.py
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

try:
    plt.style.use("seaborn-v0_8-whitegrid")
except OSError:
    pass

BLUE, TEAL, ORANGE, RED, GREEN, PURPLE = (
    "#1f6fb2", "#2ca6a4", "#e8833a", "#d64545", "#3d9e4d", "#7b6fd0")
SLA_H, OTD_TARGET = 48, 92

deliv = pd.read_csv("data/deliveries.csv", parse_dates=["date"])
daily = pd.read_csv("data/daily_volume.csv", parse_dates=["date"])
inv = pd.read_csv("data/inventory_monthly.csv")
daily["roll7"] = daily["shipments"].rolling(7, center=True).mean()

import os
os.makedirs("charts", exist_ok=True)

def save(fig, name):
    fig.tight_layout()
    fig.savefig(f"charts/{name}", dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"saved charts/{name}")

# ------------------------------------------------ 1. daily volume time series
fig, ax = plt.subplots(figsize=(10, 4.6))
ax.plot(daily["date"], daily["shipments"], color=BLUE, alpha=0.45, lw=1, label="Daily shipments")
ax.plot(daily["date"], daily["roll7"], color=RED, lw=2, label="7-day rolling average")
ax.set_title("Daily Shipment Volume with 7-Day Trend (Apr–Sep 2026)")
ax.set_ylabel("Shipments"); ax.legend(); ax.tick_params(axis="x", rotation=20)
save(fig, "fig1_volume_ts.png")
wd = daily[daily["date"].dt.dayofweek < 5]["shipments"].mean()
we = daily[daily["date"].dt.dayofweek >= 5]["shipments"].mean()
print(f"[FIG1] mean daily={daily['shipments'].mean():.0f} max={daily['shipments'].max()} "
      f"on {daily.loc[daily['shipments'].idxmax(),'date'].date()} "
      f"weekday avg={wd:.0f} weekend avg={we:.0f} (weekend dip {(1-we/wd)*100:.0f}%)")

# ------------------------------------------------ 2. delivery-time distribution
h = deliv["delivery_hours"]
fig, ax = plt.subplots(figsize=(10, 4.6))
counts, bins, _ = ax.hist(h.clip(upper=150), bins=60, color=BLUE, alpha=0.7,
                          edgecolor="white", label="Deliveries")
centers = (bins[:-1] + bins[1:]) / 2
smooth = np.convolve(counts, np.ones(7) / 7, mode="same")
ax.plot(centers, smooth, color=RED, lw=2, label="Smoothed density")
ax.axvline(SLA_H, color="black", ls="--", lw=2, label=f"SLA ({SLA_H}h)")
ax.set_title("Distribution of Delivery Times — Long Tail Beyond the SLA")
ax.set_xlabel("Hours from order to delivery"); ax.set_ylabel("Deliveries")
ax.legend()
save(fig, "fig2_delivery_time_dist.png")
print(f"[FIG2] p50={h.quantile(.5):.1f}h p90={h.quantile(.9):.1f}h p99={h.quantile(.99):.1f}h "
      f"late(>{SLA_H}h)={(h>SLA_H).mean()*100:.1f}% within24h={(h<=24).mean()*100:.1f}%")

# ------------------------------------------------ 3. OTD by zone
otd = deliv.groupby("zone")["on_time"].mean().mul(100).sort_values()
fig, ax = plt.subplots(figsize=(10, 4.6))
bars = ax.bar(otd.index, otd.values,
              color=[RED if v < 80 else (ORANGE if v < 85 else TEAL) for v in otd.values])
ax.axhline(OTD_TARGET, color="black", ls="--", lw=1.5, label=f"Target {OTD_TARGET}%")
ax.set_title("On-Time Delivery Rate by Zone (Target 92%)")
ax.set_ylabel("OTD %"); ax.set_ylim(0, 100); ax.legend()
for b, v in zip(bars, otd.values):
    ax.text(b.get_x() + b.get_width()/2, v + 1, f"{v:.1f}%", ha="center", fontsize=9)
save(fig, "fig3_otd_by_zone.png")
print(f"[FIG3] best={otd.index[-1]} {otd.iloc[-1]:.1f}% worst={otd.index[0]} {otd.iloc[0]:.1f}% "
      f"overall={deliv['on_time'].mean()*100:.1f}% zones<80%: {(otd<80).sum()}")

# ------------------------------------------------ 4. cost vs fuel price (daily aggregates)
# Per-delivery cost is dominated by distance; the fuel signal emerges cleanly
# at the daily-average level, where distance noise averages out.
davg = deliv.groupby(deliv["date"].dt.date).agg(
    avg_cost=("cost_per_delivery_rs", "mean"),
    fuel=("fuel_price_rs_l", "mean")).reset_index()
x = davg["fuel"].values; y = davg["avg_cost"].values
A = np.vstack([x, np.ones_like(x)]).T
slope, intercept = np.linalg.lstsq(A, y, rcond=None)[0]
r = np.corrcoef(x, y)[0, 1]
fig, ax = plt.subplots(figsize=(10, 4.6))
ax.scatter(x, y, s=26, alpha=0.6, color=BLUE, label="Daily average")
xs = np.linspace(x.min(), x.max(), 100)
ax.plot(xs, slope * xs + intercept, color=RED, lw=2.5,
        label=f"Trend (r={r:.2f})")
ax.set_title("Daily Average Cost per Delivery vs Fuel Price")
ax.set_xlabel("Fuel price (Rs./litre)"); ax.set_ylabel("Avg cost per delivery (Rs.)")
ax.legend()
save(fig, "fig4_cost_vs_fuel.png")
print(f"[FIG4] corr={r:.3f} slope=Rs.{slope:.2f} per Rs./L R2={r**2:.3f} "
      f"fuel range {x.min():.1f}-{x.max():.1f} Rs./L")

# ------------------------------------------------ 5. correlation heatmap
num = deliv[["package_kg", "planned_km", "actual_km", "route_deviation_pct",
             "delivery_hours", "cost_per_delivery_rs", "fuel_price_rs_l"]].corr()
fig, ax = plt.subplots(figsize=(8.5, 6.5))
im = ax.imshow(num.values, cmap="RdYlGn", vmin=-1, vmax=1)
ax.set_xticks(range(len(num.columns))); ax.set_yticks(range(len(num.columns)))
ax.set_xticklabels(num.columns, rotation=30, ha="right")
ax.set_yticklabels(num.columns)
for i in range(len(num.columns)):
    for j in range(len(num.columns)):
        ax.text(j, i, f"{num.values[i, j]:.2f}", ha="center", va="center",
                fontsize=9, color="black" if abs(num.values[i, j]) < 0.6 else "white")
fig.colorbar(im, ax=ax, label="Correlation")
ax.set_title("Correlation Heatmap — Key Operational Variables")
save(fig, "fig5_corr_heatmap.png")
c = num["on_time" ] if "on_time" in num else None
print(f"[FIG5] corr(actual_km,cost)={num.loc['actual_km','cost_per_delivery_rs']:.3f} "
      f"corr(delivery_hours,route_dev)={num.loc['delivery_hours','route_deviation_pct']:.3f} "
      f"corr(planned_km,actual_km)={num.loc['planned_km','actual_km']:.3f} "
      f"corr(package_kg,cost)={num.loc['package_kg','cost_per_delivery_rs']:.3f}")

# ------------------------------------------------ 6. failure Pareto
fr = (deliv[deliv["first_attempt_failed"]]["failure_reason"]
      .value_counts(normalize=True).mul(100))
cum = fr.cumsum()
fig, ax = plt.subplots(figsize=(10, 4.6))
bars = ax.bar(fr.index, fr.values, color=[RED, ORANGE, BLUE, TEAL, PURPLE])
ax.set_ylabel("% of failed first attempts")
ax2 = ax.twinx()
ax2.plot(fr.index, cum.values, color="black", marker="o", lw=2, label="Cumulative %")
ax2.set_ylabel("Cumulative %"); ax2.set_ylim(0, 105)
ax.set_title("Pareto Analysis — Reasons for Failed First-Attempt Deliveries")
ax.tick_params(axis="x", rotation=18)
for b, v in zip(bars, fr.values):
    ax.text(b.get_x() + b.get_width()/2, v + 0.6, f"{v:.1f}%", ha="center", fontsize=9)
save(fig, "fig6_failure_pareto.png")
print(f"[FIG6] top2={fr.index[0]}+{fr.index[1]} = {fr.iloc[:2].sum():.1f}% of failures; "
      + "; ".join(f"{k}={v:.1f}%" for k, v in fr.items()))

# ------------------------------------------------ 7. inventory turnover/stockouts
mi = inv.groupby("month").agg(turnover=("inventory_turnover", "mean"),
                              stockouts=("stockout_days", "sum")).reset_index()
fig, ax = plt.subplots(figsize=(10, 4.6))
ax.bar(mi["month"], mi["stockouts"], color=ORANGE, alpha=0.8, label="Stockout days (all categories)")
ax.set_ylabel("Stockout days", color=ORANGE)
ax2 = ax.twinx()
ax2.plot(mi["month"], mi["turnover"], color=TEAL, marker="o", lw=2.5, label="Avg turnover ratio")
ax2.set_ylabel("Inventory turnover ratio", color=TEAL)
ax.set_title("Inventory Turnover vs Stockout Days by Month")
fig.legend(loc="upper left", bbox_to_anchor=(0.08, 0.92))
save(fig, "fig7_inventory.png")
ct = inv.groupby("category")["inventory_turnover"].mean().sort_values()
print(f"[FIG7] turnover best={ct.index[-1]} {ct.iloc[-1]:.2f} worst={ct.index[0]} {ct.iloc[0]:.2f}; "
      f"stockouts peak month={mi.loc[mi['stockouts'].idxmax(),'month']} ({mi['stockouts'].max()} days)")

# ------------------------------------------------ 8. planned vs actual boxplot
fig, ax = plt.subplots(figsize=(10, 4.6))
data = [deliv[deliv["zone"] == z]["route_deviation_pct"].clip(-20, 80) for z in
        sorted(deliv["zone"].unique())]
bp = ax.boxplot(data, labels=sorted(deliv["zone"].unique()), patch_artist=True)
for p in bp["boxes"]:
    p.set_facecolor(BLUE); p.set_alpha(0.6)
ax.axhline(0, color="black", ls="--", lw=1.2, label="Planned = actual")
ax.set_title("Route Deviation (Actual vs Planned Distance) by Zone")
ax.set_ylabel("Deviation %"); ax.legend()
save(fig, "fig8_planned_vs_actual.png")
med = deliv.groupby("zone")["route_deviation_pct"].median().sort_values(ascending=False)
print(f"[FIG8] worst zone={med.index[0]} median dev {med.iloc[0]:.1f}% "
      f"best={med.index[-1]} {med.iloc[-1]:.1f}% overall mean={deliv['route_deviation_pct'].mean():.1f}%")

print("ALL CHARTS DONE")
