"""
build_docx.py — converts report.md to a styled .docx with embedded chart PNGs.
Run:  python build_docx.py
"""
import re
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

doc = Document()
style = doc.styles["Normal"]
style.font.name = "Calibri"
style.font.size = Pt(11)

def shade(par, color="F2F2F2"):
    pPr = par._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:fill"), color)
    pPr.append(shd)

def add_runs(par, text):
    # minimal **bold** handling
    for i, chunk in enumerate(re.split(r"(\*\*.+?\*\*)", text)):
        if not chunk:
            continue
        if chunk.startswith("**") and chunk.endswith("**") and len(chunk) > 4:
            r = par.add_run(chunk[2:-2]); r.bold = True
        else:
            par.add_run(chunk)

lines = open("report.md").read().splitlines()
i, in_code = 0, False
first_h1 = True
while i < len(lines):
    ln = lines[i]
    if ln.strip().startswith("```"):
        in_code = not in_code
        i += 1
        continue
    if in_code:
        p = doc.add_paragraph()
        r = p.add_run(ln if ln else " ")
        r.font.name = "Consolas"; r.font.size = Pt(8.5)
        r.font.color.rgb = RGBColor(0x33, 0x33, 0x33)
        shade(p)
        i += 1
        continue
    s = ln.strip()
    if not s or s == "---":
        i += 1
        continue
    if s.startswith("# "):
        if first_h1:
            doc.add_heading(s[2:], level=0); first_h1 = False
        else:
            doc.add_heading(s[2:], level=1)
    elif s.startswith("## "):
        doc.add_heading(s[3:], level=1)
    elif s.startswith("### "):
        doc.add_heading(s[4:], level=2)
    elif s.startswith("!["):
        m = re.match(r"!\[(.*?)\]\((.*?)\)", s)
        alt, path = m.group(1), m.group(2)
        doc.add_picture(path, width=Inches(6.0))
        doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
        cap = doc.add_paragraph()
        cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = cap.add_run(alt); r.italic = True; r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    elif s.startswith("|"):
        # collect table block
        tbl_lines = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            tbl_lines.append(lines[i].strip()); i += 1
        rows = [[c.strip() for c in r.strip("|").split("|")] for r in tbl_lines]
        rows = [r for r in rows if not all(set(c) <= set("-: ") for c in r)]
        t = doc.add_table(rows=len(rows), cols=len(rows[0]))
        t.style = "Table Grid"
        for ri, row in enumerate(rows):
            for ci, cell in enumerate(row):
                cell_p = t.rows[ri].cells[ci].paragraphs[0]
                add_runs(cell_p, cell)
                if ri == 0:
                    for run in cell_p.runs:
                        run.bold = True
        doc.add_paragraph()
        continue
    elif s.startswith("- "):
        p = doc.add_paragraph(style="List Bullet")
        add_runs(p, s[2:])
    else:
        p = doc.add_paragraph()
        add_runs(p, s)
    i += 1

# page setup: reasonable margins
for sec in doc.sections:
    sec.left_margin = Inches(0.9); sec.right_margin = Inches(0.9)

doc.save("/home/hatch/workspace/your_files/Week3_Logistics_Data_Analysis_Visualization_Report.docx")
print("docx saved")

# report stats
n_charts = len(doc.inline_shapes)
words = sum(len(p.text.split()) for p in doc.paragraphs)
words += sum(len(c.text.split()) for t in doc.tables for r in t.rows for c in r.cells)
print(f"embedded images: {n_charts} | approx words: {words}")
