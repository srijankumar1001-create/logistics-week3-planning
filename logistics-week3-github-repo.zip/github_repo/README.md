# Week 3 — Advanced Data Analysis and Visualization in Logistics

Exploratory data analysis of last-mile delivery and inventory data for a regional
distribution hub (urban + semi-urban zones). Continues the Week 1 strategic plan
and the Week 2 preprocessing pipeline of the same internship project.

A synthetic six-month dataset (1 Apr – 30 Sep 2026, 36,637 deliveries, 8 zones)
is generated with fixed seeds, analyzed, and visualized. Every number in the
report was computed by these scripts — nothing was hand-estimated.

## Repository layout

| Path | What it is |
|---|---|
| `scripts/generate_dataset.py` | Simulates the dataset: per-delivery records, daily volumes + fuel prices, monthly inventory (saves to `data/`) |
| `scripts/make_charts.py` | Runs the EDA, prints every statistic cited in the report, and saves 8 PNG charts to `charts/` |
| `scripts/build_docx.py` | Converts `report.md` to the Word report, embedding the chart PNGs with captions |
| `charts/` | The 8 generated figures (volume trend, delivery-time distribution, OTD by zone, cost vs fuel, correlation heatmap, failure Pareto, inventory turnover, route deviation) |
| `Week3_Logistics_Data_Analysis_Visualization_Report.docx` | The full analytical report |

## How to run (in order)

```bash
pip install -r requirements.txt
python scripts/generate_dataset.py   # creates data/
python scripts/make_charts.py        # prints stats, creates charts/
python scripts/build_docx.py         # builds the .docx (run from repo root)
```

## Key findings

- Measured on-time delivery: **74.5%** (below the Week 1 planning estimate of ~82%)
- Semi-urban zones average **61.7%** OTD at ~2x urban cost; worst zone Z8 at 57.9%
- Delivery times are long-tailed: median 32.3h, p90 70.9h, **25.5%** breach the 48h SLA
- Top two failure causes (customer unavailable, bad address) = **71.5%** of failures
- Cost is driven by distance (r = 0.998); fuel is secondary (r = 0.30 at daily level)
- Routes overrun plans by **13.3%** on average — a planning, not a driving, problem

## Tech stack

Python 3 · pandas · NumPy · matplotlib · python-docx
